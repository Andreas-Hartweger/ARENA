// One-off QA adapter for the interrupted 02B reference. Run from the project
// root with a separate clean checkout of the original SHA as argv[2].
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {join,resolve} from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {performance} from 'node:perf_hooks';
import process from 'node:process';

const expectedSha='44c100c22854793b200a104dbc358e49ea9190fa';
const directory=resolve('docs/first-evolution/evidence/reference-release');
const stand=resolve(process.argv[2]);
assert.equal(execFileSync('git',['-C',stand,'rev-parse','HEAD'],{encoding:'utf8'}).trim(),expectedSha);
assert.equal(execFileSync('git',['-C',stand,'status','--porcelain'],{encoding:'utf8'}).trim(),'');
const load=(p)=>import(pathToFileURL(join(stand,p)).href);
const {digest}=await load('scripts/evolution-runtime.mjs');
const {Evolution}=await load('src/training/evolution.ts');
const {model}=await load('src/training/genome.ts');
const {scenario}=await load('src/training/episode.ts');
const {derivedSeed}=await load('src/training/random.ts');
const file=(name)=>join(directory,name);
const json=(name)=>JSON.parse(fs.readFileSync(file(name),'utf8'));
const lines=(name)=>fs.readFileSync(file(name),'utf8').trimEnd().split('\n');
assert.ok(!fs.existsSync(file('end.json')));
const meta=json('run.json'),summaryLines=lines('generations.ndjson'),episodeLines=lines('episodes.ndjson');
const summaries=summaryLines.map(line=>JSON.parse(line));
const count=summaries.length;
assert.ok(count>=77&&count<100);
assert.equal(episodeLines.length,count*128);
assert.equal(meta.sha,expectedSha);
const s=scenario(digest,{seed:derivedSeed(42,'scenario')});
const evolution=new Evolution(model(s.modelSignature),[s],digest,{runId:'reference',n:128,generations:100,randomSearch:false});
const plain=v=>JSON.parse(JSON.stringify(v));
assert.deepEqual(plain(evolution.config),meta.config);
assert.equal(s.key,meta.scenario);
const beforeReconstruction=performance.now();
for(let g=0;g<count;g++){
 const from=g*128;
 const input=episodeLines.slice(from,from+128).map(line=>JSON.parse(line));
 let i=0;
 const rows=evolution.collect((scenario,genome)=>{
   const r=input[i];assert.deepEqual([r.generation,r.slot,r.hash,r.id],[g,i,genome.hash,evolution.population[i].id]);i++;
   const {contract,seed,scenario:position,attempt,...raw}=r.episodes[0];
   assert.deepEqual([contract,seed,position,attempt],[scenario.key,scenario.seed,0,0]);
   return raw; // The evaluator here reads an existing observed result. It never steps a world.
 });
 const {records,before,...current}=evolution.commit(rows);
 const {ms,cpu,before:memoryBefore,after,...stored}=summaries[g];
 assert.ok(ms>0&&cpu.user>=0&&memoryBefore.rss>0&&after.rss>0);
 assert.deepEqual(before,{p:0.05,alpha:0.2});
 assert.deepEqual(plain(current),stored);
 assert.deepEqual(records.map(r=>JSON.stringify({generation:g,...r})),episodeLines.slice(from,from+128));
}
const firstPrefix=JSON.parse(fs.readFileSync(join(directory,'../interrupted-prefix.json'),'utf8'));
for(let g=0;g<77;g++)assert.equal(createHash('sha256').update(episodeLines.slice(g*128,(g+1)*128).join('\n')+'\n').digest('hex'),firstPrefix.generationHashes[g]);
const reconstructionMs=performance.now()-beforeReconstruction;
const info={originalSha:expectedSha,adapterSha256:createHash('sha256').update(fs.readFileSync(fileURLToPath(import.meta.url))).digest('hex'),previouslyDrivenGenerations:count,previouslyDrivenEpisodes:count*128,simulatedDuringReconstruction:0,reconstructedGenerations:count,reconstructionMs,nextGeneration:count,tailStarted:new Date().toISOString(),firstTailPopulation:evolution.population.map(m=>m.genome.hash)};
const log=()=>fs.writeFileSync(file('continuation.json'),JSON.stringify(info,null,2)+'\n');
log();
console.log('Reconstructed '+count+' verified generations, simulated zero cars. Starting G'+count);
let totalMs=summaries.reduce((sum,r)=>sum+r.ms,0);
while(evolution.population.length){
 const start=performance.now(),cpu=process.cpuUsage(),before=process.memoryUsage();
 const summary=evolution.commit(evolution.collect()); // Normal, real DriveWorld/Brain evaluator for every remaining slot.
 const {records,...statistics}=summary;
 const row={...statistics,ms:performance.now()-start,cpu:process.cpuUsage(cpu),before,after:process.memoryUsage()};
 totalMs+=row.ms;
 fs.appendFileSync(file('generations.ndjson'),JSON.stringify(row)+'\n');
 fs.appendFileSync(file('episodes.ndjson'),records.map(r=>JSON.stringify({generation:summary.generation,...r})).join('\n')+'\n');
 process.stdout.write(JSON.stringify({g:summary.generation,n:records.length,success:summary.successes,best:summary.fitness.best,ms:row.ms})+'\n');
}
info.tailFinished=new Date().toISOString();
info.newlyDrivenGenerations=100-count;
info.newlyDrivenEpisodes=128*(100-count);
log();
fs.writeFileSync(file('end.json'),JSON.stringify({generations:evolution.history.length,evaluations:evolution.history.reduce((sum,r)=>sum+r.evaluations,0),elapsedMs:totalMs,timingDefinition:'Summe der gemessenen Generations-Walltimes. Unterbrechung, Rekonstruktion und Datei-I/O zwischen Generationen sind ausgenommen.',calendarElapsedMs:Date.parse(info.tailFinished)-Date.parse(meta.started),champion:evolution.champion.genome.hash},null,2)+'\n');

